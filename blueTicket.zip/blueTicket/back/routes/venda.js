import express from 'express';
const router = express.Router();
import { listar, cadastrarEventos, detalhesEvento } from '../controllers/venda.js';

router.get('/', listar);
router.post('/cadastrarEventos', cadastrarEventos);
router.get('/:id', detalhesEvento); 

export { router };
