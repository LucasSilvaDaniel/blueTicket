const evento = [
    { id: 1, nome: 'Pedro Sampaio', local: "Florianópolis", descricao: "Proibido ficar parado", preco: 500, foto: "https://s2-gshow.glbimg.com/RPeubMbKt9VoDLIwKy-AdARWraI=/0x0:1366x632/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_e84042ef78cb4708aeebdf1c68c6cbd6/internal_photos/bs/2021/f/R/UAeA9zSK2tIlpn3g4dGw/pedro-sampaio-domingao.png" },
    { id: 2, nome: 'Xuxa', local: "Coritiba", descricao: "Somente baixinhos", preco: 100, foto: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFGumyyfrwGKQH6guZCMJnUeLXXITDowXTSQ&s" },
    { id: 3, nome: 'Pablo Vitar', local: "Cuba", descricao: "Uma nova onda", preco: 250, foto: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzPhjHe0YfwBcW3BXs8iLKUehl2UCzVcByUQ&s" }
];

const listar = (req, res) => {
    res.status(200).send(evento);
};

const cadastrarEventos = (req, res) => {
    const show = req.body;
    evento.push(show);
    res.status(201).send(show);
};

const detalhesEvento = (req, res) => {
    const id = parseInt(req.params.id); 
    const eventoEncontrado = evento.find(e => e.id === id); 

    if (eventoEncontrado) {
        res.status(200).send(eventoEncontrado);
    } else {
        res.status(404).send({ message: "Evento não encontrado" });
    }
};

export { listar, cadastrarEventos, detalhesEvento };
