import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

const Detalhes = () => {
    const { id } = useParams();
    const [evento, setEvento] = useState(null);

    useEffect(() => {
        fetchEvento();
    }, [id]);

    const fetchEvento = async () => {
        try {
            const response = await fetch(`http://localhost:3000/venda/${id}`);
            if (!response.ok) {
                const errorText = await response.text();
                console.error('Erro ao buscar detalhes do evento:', errorText);
                return;
            }
            const data = await response.json();
            setEvento(data);
        } catch (error) {
            console.error('Erro ao buscar detalhes do evento:', error);
        }
    };

    if (!evento) return <div>Carregando detalhes...</div>;

    return (
        <div className="detalhes-container">
            <h1>{evento.nome}</h1>
            <img src={evento.foto} alt={evento.nome} />
            <p>Local: {evento.local}</p>
            <p>Descrição: {evento.descricao}</p>
            <p>Preço: R$ {evento.preco}</p>
            <Link to="/">Voltar</Link>
        </div>
    );
};

export default Detalhes;
