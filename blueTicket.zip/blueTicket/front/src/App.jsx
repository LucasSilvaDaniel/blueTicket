import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import './App.css';
import Detalhes from './detalhes.jsx';

function App() {
    const [eventos, setEventos] = useState([]);

    useEffect(() => {
        fetchEventos();
    }, []);

    const fetchEventos = async () => {
        try {
            const response = await fetch('http://localhost:3000/venda/');
            const data = await response.json();
            setEventos(data);
        } catch (error) {
            console.error('Erro ao buscar eventos:', error);
        }
    };

    return (
        <Router>
            <Routes>
                <Route path="/" element={
                    <div>
                        <h1>Eventos</h1>
                        <div className="eventos-container">
                            {eventos.map((evento) => (
                                <div key={evento.id} className="evento-card">
                                    <h2>{evento.nome}</h2>
                                    <img src={evento.foto} width={400} alt={evento.nome} />
                                    <p>Local: {evento.local}</p>
                                    <p>Descrição: {evento.descricao}</p>
                                    <p>Preço: R$ {evento.preco}</p>
                                    <Link to={`/detalhes/${evento.id}`}>Ver Detalhes</Link>
                                </div>
                            ))}
                        </div>
                    </div>
                } />
                <Route path="/detalhes/:id" element={<Detalhes />} />
            </Routes>
        </Router>
    );
}

export default App;
